<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require './vendor/phpmailer/phpmailer/src/Exception.php';
    require './vendor/phpmailer/phpmailer/src/PHPMailer.php';
    require './vendor/phpmailer/phpmailer/src/SMTP.php';

  // Include autoload.php file
    require './vendor/autoload.php';
  // Create object of PHPMailer class

    $output = '';
  
    if(isset($_POST['submit'])) {
        $mail = new PHPMailer(true);
        $mail->SMTPDebug = 3;
        $mail->isSMTP();
        $mail->Host = 'smtp.truehost.cloud';
        $mail->SMTPAuth = true;
        $mail->Username = 'info@kingdomwayschools.com';
        $mail->Password = 'Kingdomwayschool';
        $mail->SMTPSecure = "tls";
        $mail->Port = 587;
        $mail->setFrom('info@kingdomwayschools.com', 'Mailer');
        $mail->addAddress('alex@kingdomwayschools.com');
        $mail->addReplyTo($_POST['email'], $_POST['name'], $_POST['phone']);

        $mail->isHTML(true);
        $mail->Subject = $_POST['subject'];
        $mail->Body = $_POST['message'];
        
        try {
            $mail->send();
            echo 'Your message was sent successfully!';
        } catch (Exception $e) {
            echo "Your message could not be sent! PHPMailer Error: {$mail->ErrorInfo}";
        }
        
    } else {
        echo "There is a problem with the contact html document!";
    }

?>